var swiper = new Swiper(".mySwiper", {
  spaceBetween: 30,
  mousewheel: true,
  keyboard: true,
});




const smoothLinks = document.querySelectorAll("a[href^='#']");
for (let smoothLink of smoothLinks) {
    smoothLink.addEventListener("click", function (e) {
        e.preventDefault();
        const id = smoothLink.getAttribute("href");

        document.querySelector(id).scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    });
};



IMask(
  document.getElementById('tel'),
  {
    mask: '+{7}(000)000-00-00'
  }
)



IMask(
  document.getElementById('num'),
  {
    mask: Number,
    min: 1,
    max: 10,
    thousandsSeparator: ' '
  }
)



const clickBtn = document.getElementById('btn');

clickBtn.addEventListener('click', () => {
  alert('Заявка отправлена');
});